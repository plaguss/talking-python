# Explore Talking Python app

It is inspired by [KnowledgeGPT](https://knowledgegpt.streamlit.app/)
